INSERT INTO auth.fixture VALUES ('fake-seed-0000');
